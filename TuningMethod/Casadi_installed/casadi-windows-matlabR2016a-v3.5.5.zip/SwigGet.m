function ptr = SwigGet(self)
  ptr = [];
end
